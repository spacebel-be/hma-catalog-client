/**
 * SpaceMapUtils
 * -------------
 * @author Christophe Noel - Spacebel
 * @date March 2012
 * SpaceMapUtils includes all the usefull functions :
 * 
 */

var SpaceMapUtils = {
		
		// Hold the value of a coordinate to transfer to an input field
		totransferValue: null,
		/**
		 * createAOIGML
		 * Read the Polygon coordinates in olAOI hidden input field and creates "SSE" GML (syntax using schema above
		 * @return GML representation of the AOI
		 */
		createAOIGML: function() {
			var xAOI = document.getElementById('olAOI').value;
			if (xAOI == '') {
				return "<noAreaOfInterest/>";
			} else {
				//
				var ExpResult = xAOI.split(/POLYGON\(\(|\,/);
				
				var fAOI ='';
				if(SpaceMapSettings.AOI_FORMAT =="SSEGML311"){
					var gmlId = "SSEAOI" + new Date().getTime();
					fAOI = '<?xml version="1.0" encoding="UTF-8"?>';
					fAOI = fAOI + '<aoi:AreaOfInterest xmlns:aoi="http://www.esa.int/xml/schemas/mass/aoifeatures" xmlns:gml="http://www.opengis.net/gml" gml:id="' + gmlId +'" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.esa.int/xml/schemas/mass/aoifeatures http://services.eoportal.org/schemas/1.6/gml/GML3.1.1/aoifeatures.xsd">';
					fAOI = fAOI + 	'<gml:boundedBy>';
					fAOI = fAOI + 		'<gml:Envelope srsName="urn:x-ogc:def:crs:EPSG:4326">';
					fAOI = fAOI + 			'<gml:lowerCorner>';
					fAOI = fAOI + 				this.invertLatLon(ExpResult[1]);
					fAOI = fAOI + 			'</gml:lowerCorner>';
					fAOI = fAOI + 			'<gml:upperCorner>';
					fAOI = fAOI + 				this.invertLatLon(ExpResult[3]);
					fAOI = fAOI + 			'</gml:upperCorner>';
					fAOI = fAOI + 		'</gml:Envelope>';
					fAOI = fAOI + 	'</gml:boundedBy>';
					fAOI = fAOI + 	'<gml:featureMember>';
					fAOI = fAOI + 		'<aoi:Feature gml:id="'+ gmlId +'.0001' +'">';
					fAOI = fAOI + 			'<gml:boundedBy>';
					fAOI = fAOI + 				'<gml:Envelope srsName="urn:x-ogc:def:crs:EPSG:4326">';
					fAOI = fAOI + 					'<gml:lowerCorner>';
					fAOI = fAOI + 						this.invertLatLon(ExpResult[1]);
					fAOI = fAOI + 					'</gml:lowerCorner>';
					fAOI = fAOI + 					'<gml:upperCorner>';
					fAOI = fAOI + 						this.invertLatLon(ExpResult[3]);
					fAOI = fAOI + 					'</gml:upperCorner>';
					fAOI = fAOI + 				'</gml:Envelope>';
					fAOI = fAOI + 			'</gml:boundedBy>';
					fAOI = fAOI + 			'<aoi:geometry>';
					fAOI = fAOI + 				'<gml:Polygon srsName="urn:x-ogc:def:crs:EPSG:4326">';
					fAOI = fAOI + 					'<gml:exterior>';
					fAOI = fAOI + 						'<gml:LinearRing>';
					fAOI = fAOI + 							'<gml:posList>';
					fAOI = fAOI + 								this.invertLatLon(ExpResult[1]) + " "
								+ 								this.invertLatLon(ExpResult[2]) + " "
								+ 								this.invertLatLon(ExpResult[3])	+ " "
								+								this.invertLatLon(ExpResult[4]) + " "
								+ 								this.invertLatLon(ExpResult[1]);
					fAOI = fAOI + 							'</gml:posList>';
					fAOI = fAOI + 						'</gml:LinearRing>';
					fAOI = fAOI + 					'</gml:exterior>';
					fAOI = fAOI + 				'</gml:Polygon>';
					fAOI = fAOI + 			'</aoi:geometry>';
					fAOI = fAOI + 		'</aoi:Feature>';
					fAOI = fAOI + 	'</gml:featureMember>';
					fAOI = fAOI + '</aoi:AreaOfInterest>';
				}else{
					fAOI = '<?xml version="1.0" encoding="UTF-8"?><aoi:AreaOfInterest xmlns:aoi="http://www.esa.int/xml/schemas/mass/aoifeatures" xmlns:gml="http://www.opengis.net/gml"><gml:featureMembers><aoi:Feature><gml:boundedBy><gml:Envelope srsName="urn:x-ogc:def:crs:EPSG:4326"><gml:lowerCorner>';
					// TODO can we be sure that 1st is lower left corner ?
					fAOI = fAOI + this.invertLatLon(ExpResult[1]);
					fAOI = fAOI + '</gml:lowerCorner><gml:upperCorner>';
					fAOI = fAOI + this.invertLatLon(ExpResult[3]);
					fAOI = fAOI + '</gml:upperCorner></gml:Envelope></gml:boundedBy><aoi:geometry><gml:Polygon srsName="urn:x-ogc:def:crs:EPSG:4326"><gml:exterior><gml:LinearRing><gml:posList>';
					fAOI = fAOI + this.invertLatLon(ExpResult[1]) + " "
							+ this.invertLatLon(ExpResult[2]) + " " + this.invertLatLon(ExpResult[3])
							+ " " + this.invertLatLon(ExpResult[4]) + " "
							+ this.invertLatLon(ExpResult[1]) + '</gml:posList>';
					fAOI = fAOI + '</gml:LinearRing></gml:exterior></gml:Polygon></aoi:geometry></aoi:Feature></gml:featureMembers></aoi:AreaOfInterest>';
				}				
			}
			return fAOI;
		},
		/**
		 * invertLatLon
		 * Inversion of latitude and longitude: in a string such as "x y" -> "y x" only if SpaceMapSettings.latlon is true
		 * Note: OpenLayers use lon lat instead of lat lon (TODO check in OL v2.11)
		 * @param coord
		 * @returns
		 */
		invertLatLon: function(coord) {
			var lc = coord.substring(0, coord.indexOf(" ", 0));
			var rc = coord.substring(coord.indexOf(" ", 0) + 1, coord.length);
			if (SpaceMapSettings.LATLON) {
				var newCoord = rc + " " + lc;
				return newCoord;
			} else {
				return coord;
			}
		},
		/**
		 * Add a WMS layer to the map
		 * @param url :  WMS url
		 * @param layer : layer title
		 * @return
		 */
		addWMSLayer: function(url, layer) {			
			var userWMS = new OpenLayers.Layer.WMS(layer, url, {
				transparent : true,
				layers : [ layer ]
			}, {
				isBaseLayer : false,
				buffer : 0,
				displayInLayerSwitcher : true
			});
			SpaceMap.spacemap.addLayers( [ userWMS ]);
		},
		
		/**
		 * displayFeatureInfo 
		 * Creates an info tip on a given feature It is a
		 * functionality available for onSelectActionDefinition
		 * @param feature: the concerned feature (Openlayers.Feature.Vector)
		 * @param content:the text to display
		 * @return
		 */
		displayFeatureInfo: function (feature, content) {
			SpaceMapUI.featureinfopopup("Feature", feature,content, SpaceMap.selectControl);
			// unselect feature when the popup
			// is closed
		},
		/**
		 * selectFeatureByFid
		 * Select on the result layer the feature with the given fid
		 * @param fid
		 */
		selectFeatureByFid: function(fid) {
			var feature = SpaceMapUtils.getFeatureByFid(SpaceMap.rlayer, fid);
			SpaceMap.selectControl.select(feature);
		},

		/**
		 * unselectFeatureByFid unselects a feature
		 *
		 * @param fid :
		 *            feature id
		 * @return
		 */
		unselectFeatureByFid:function (fid) {
			var feature = SpaceMapUtils.getFeatureByFid(SpaceMap.rlayer, fid);
			SpaceMap.selectControl.unselect(feature);
		},

		/**
		 * changeSelectFeatureByFid selects a feature or unselects it
		 * (on result layer)
		 * @param fid :
		 *            feature id
		 * @return
		 */
		changeSelectFeatureByFid:function (fid) {
			var feature = SpaceMapUtils.getFeatureByFid(SpaceMap.rlayer, fid);
			if (feature.popup) {
				SpaceMap.selectControl.unselect(feature);
			} else {
				SpaceMap.selectControl.select(feature);
			}
		},

		/**
		 * Change highlight of a given feature
		 * (on result layer)
		 * @param fid
		 * @param checked
		 */
		changeHighlightByFid: function (fid, checked) {
			var feature = SpaceMapUtils.getFeatureByFid(SpaceMap.rlayer, fid);
			if (!checked) {
				SpaceMap.selectControl.unhighlight(feature);
			} else {
				SpaceMap.selectControl.highlight(feature);
			}
		},
		
		/**
		 * Change highlight all features
		 * (on result layer)
		 * @param checked
		 */
		changeHighlightAllFeatures: function (checked) {
			var features = SpaceMap.rlayer.features;
			if (typeof features == 'undefined') {
				// do nothing
			}else{
				for ( var i = 0, len = features.length; i < len; ++i) {
					if (!checked) {
						SpaceMap.selectControl.unhighlight(features[i]);
					} else {
						SpaceMap.selectControl.highlight(features[i]);
					}
				}
			}
		},
		

		/**
		 * getFeatureByFid returns Openlayers.Feature with the given featureId
		 *
		 * @param layer :
		 *            the layers where to find the feature
		 * @param featureId :
		 *            fid
		 * @return the feature and null if no result
		 */
		getFeatureByFid: function (layer, featureId) {
			var features = layer.features;
			var feature = null;
			if (typeof features == 'undefined') {
				return null;
			}
			for ( var i = 0, len = features.length; i < len; ++i) {
				if (features[i].fid == featureId) {
					feature = features[i];
					break;
				}
			}
			return feature;
		}
,
		/**
		 * Add a feature to the result layer
		 * @param feature
		 * @return
		 */
		displayResultFeature: function (feature) {
			SpaceMap.rlayer.addFeatures(feature);
		},
		/**
		 * displayAOIGML parses a AOI GML string (SSE format) and display it on a map layer
		 * @param mylayer :
		 *            layer where to display
		 * @param req :
		 *            gml as a string
		 * @return
		 */

		displayAOIGML:function (layerName, req) {
			// GML parser
			g = new OpenLayers.Format.GML.v3( {

				featureType : 'Feature',
				featureNS : 'http://www.esa.int/xml/schemas/mass/aoifeatures',
				externalProjection : new OpenLayers.Projection(SpaceMapSettings.SERVICE_PROJECTION),
				internalProjection : SpaceMap.spacemap.getProjectionObject()
			});
			
			if (SpaceMapSettings.LATLON_RESPONSE) {
				g.xy = false;
			} else {
				g.xy = true;
			}
			features = g.read(this.toValidXML(req));
			// TODO replace for(var in by basic for loop
			for ( var feat = 0, len = features.length; feat < len; ++feat) {
				myfeature = features[feat];
				// escape because of unknown bug -> loop to replace TODO
				/**
				 * The features id are set according to the xml-attribute "id" or "fid"
				 * If none are present (most of old client only have a sr:id subelement
				 * then we set the id to the gml-attribute id (a gml attribute is a
				 * feature sub element) Note that the GML parser algorithms are
				 * available at
				 * http://trac.openlayers.org/browser/trunk/openlayers/lib/OpenLayers/Format/GML.js
				 */
				if (typeof (myfeature) != "undefined" && myfeature.fid == null
						&& typeof (myfeature.attributes.id) != "undefined") {
					myfeature.fid = myfeature.attributes.id;
				}
				
				SpaceMap.spacemap.getLayersByName(layerName)[0].addFeatures(myfeature);
				
			}
			/**
			 * Activate the selectControl which display popup infos
			 */
			SpaceMap.selectControl.activate();
		},
		
		/**
		 * displayGML parses a GML string (SSE format) and display it on a map layer
		 * @param mylayer :
		 *            layer where to display
		 * @param req :
		 *            gml as a string
		 * @return
		 */

		/**
		 * displayGML parses a GML string (SSE format) and display it on a map layer
		 * @param mylayer :
		 *            layer where to display
		 * @param req :
		 *            gml as a string
		 * @return
		 */

		displayGML:function (layerName, req) {			
			// IE fix
			if(req.length >2) {
			
			// GML parser
			g = new OpenLayers.Format.GML.v3( {

				featureType : 'Feature',
				featureNS : 'http://www.esa.int/xml/schemas/mass/serviceresult',
				externalProjection : new OpenLayers.Projection(SpaceMapSettings.SERVICE_PROJECTION),
				internalProjection : SpaceMap.spacemap.getProjectionObject()
			});
			
			if (SpaceMapSettings.LATLON_RESPONSE) {
				g.xy = false;
			} else {
				g.xy = true;
			}
			features = g.read(this.toValidXML(req));
			// TODO replace for(var in by basic for loop
			for ( var feat = 0, len = features.length; feat < len; ++feat) {
				myfeature = features[feat];
				// escape because of unknown bug -> loop to replace TODO
				/**
				 * The features id are set according to the xml-attribute "id" or "fid"
				 * If none are present (most of old client only have a sr:id subelement
				 * then we set the id to the gml-attribute id (a gml attribute is a
				 * feature sub element) Note that the GML parser algorithms are
				 * available at
				 * http://trac.openlayers.org/browser/trunk/openlayers/lib/OpenLayers/Format/GML.js
				 */
				if (typeof (myfeature) != "undefined" && myfeature.fid == null
						&& typeof (myfeature.attributes.id) != "undefined") {
					myfeature.fid = myfeature.attributes.id;
				}				
				SpaceMap.spacemap.getLayersByName(layerName)[0].addFeatures(myfeature);
				
			}
			/**
			 * Activate the selectControl which display popup infos
			 */
			SpaceMap.selectControl.activate();
			}
		},

		/**
		 * clearResults remove all the features displayed on the result layer
		 *
		 * @return
		 */
		clearResults: function () {
			for ( var feat = 0, len = SpaceMap.rlayer.features.length; feat < len; ++feat) {
				if (SpaceMap.rlayer.features[feat].popup) {
					SpaceMap.rlayer.features[feat].popup.close();
					SpaceMap.rlayer.features[feat].popup = null;
				}
			}
			SpaceMap.rlayer.destroyFeatures();
			SpaceMap.rlayer.redraw();
		},
 
		/**
		 * Use by Handle control
		 * TODO document 
		 */
		handleMeasurements:function (event) {
			var geometry = event.geometry;
			var units = event.units;
			var order = event.order;
			var measure = event.measure;
			var element = document.getElementById('output');
			var out = "";
			if (order == 1) {
				out += "Measure: " + measure.toFixed(3) + " " + units;
			} else {
				out += "Measure: " + measure.toFixed(3) + " " + units + "<sup>2</"
						+ "sup>";
			}
			alert(out);
		},

		/**
		 *  clearAOI()
		 *  destroy all features of the AOI layer
		 */
		clearAOI: function () {
			SpaceMap.vlayer.destroyFeatures();
			document.getElementById('olAOI').value = "";
			aoi_items = 0;
		},
		/**
		 * toValidXML 
		 * In some cases, the XML is partially unescaped by the browser
		 * (&amp; -gets &). The function escaped the & to &amp; if they are not already
		 * escaped.
		 */
		toValidXML: function (myHTML) {
			var reAMP = /&(?!amp;)/gi;
			// HACK for GML:id
			var reGML = /gml:id/gi;
			var strXML = myHTML.replace(reAMP, "&amp;").replace(reGML, "id");
			return strXML;
		},

		/**
		 * Target Click event use for coordinates copy to input field
		 * @param evt
		 */
		clickEvent: function (evt) {
			var item = $(Event.element(evt));
			item.value = this.totransferValue;
			Event.stopObserving("content-wrapper", "click", clickEvent);
		},
		/**
		 * Transfer value puts a value in a clicked input
		 *
		 * @param value
		 * @return
		 */
		transferValue: function (value) {
			this.totransferValue = value;
			Event.observe("content-wrapper", "click", clickEvent);
			// TODO checks if input ofthe form
		}



		
		
};