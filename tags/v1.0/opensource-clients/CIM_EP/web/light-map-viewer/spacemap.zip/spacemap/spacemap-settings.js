/**
 * Viewer Configuration - Layers, Settings, ... Spacebel - Christophe NOEL
 * 
 * Note for developpers: The settings can be also rewritten on client site, as
 * shown below : <script type="text/javascript" LANGUAGE="JavaScript">
 * jQuery(document).ready( function() { SpaceMapSettings.LATLON = false; });
 * <script>
 */

var SpaceMapSettings = {

	/**
	 * Base Layer (background map) configuration layer can be configured below
	 */
	// Default Baselayer Zoom Level
	DEFAULT_ZOOM : 5,
	// Default Map Center (longitude latitude) - specified in EPSG:4326
	//CENTERMAP : new OpenLayers.LonLat(4.8, 50.4),
	CENTERMAP : new OpenLayers.LonLat(9.1, 18.2),
	// Default Base Layer (use the entry title)
	DEFAULT_BASELAYER : "OpenStreetMap WMS",
	// List of custom WMS
	WMS_BASELAYERS : [

			{
				title : "OSM" // Not WMS : image Tile (for testing only)
			},
			{
				title : "GoogleHybrid" // Not WMS
			},
			/**
			 * { title : "GooglePhysical", }, 
			 */
			{
				title : "OpenStreetMap WMS",
				// WMS URL
				url : "http://129.206.228.72/cached/osm",
				// List of requested layers
				layers :  'osm_auto:all',
				// WMS Projection to Use (i.e "EPSG:4326")
				projection : "EPSG:4326",				
				// WMS Maximum Extent (i.e : new OpenLayers.Bounds(-180, -90,
				// 180, 90)
				maxextent : new OpenLayers.Bounds(-180, -90, 180, 90)

			},
			{
				title : "Demis Custom",
				// WMS URL
				url : "http://www2.demis.nl/worldmap/wms.asp",
				// List of requested layers
				layers : 'Countries,Topography,Builtup areas,Coastlines,Rivers,Streams,Borders,Cities,Bathymetry',
				// WMS Projection to Use (i.e "EPSG:4326")
				projection : "EPSG:4326",
				// WMS Maximum Extent (i.e : new OpenLayers.Bounds(-180, -90,
				// 180, 90)
				maxextent : new OpenLayers.Bounds(-180, -90, 180, 90)
			}, {
				title : "Metacarta",
				// WMS URL
				url : "http://vmap0.tiles.osgeo.org/wms/vmap0",
				// List of requested layers
				layers :  'basic',
				// WMS Projection to Use (i.e "EPSG:4326")
				projection : "EPSG:4326",
				// WMS Maximum Extent (i.e : new OpenLayers.Bounds(-180, -90,
				// 180, 90)
				maxextent : new OpenLayers.Bounds(-180, -90, 180, 90)
			} ],
	// latlon order for service input (some EPSG service have lon lat: set to
	// false)
	LATLON : true,
	// latlon order for service output (may differ from input !!)
	LATLON_RESPONSE : true,
	// Projection used in request/response of the service (WPS, SPS, SOS, ...)
	SERVICE_PROJECTION : "EPSG:4326",
	// Viewer width (0 = auto fit)
	VIEWER_WIDTH : 0,
	// Maximum number of AOI that a user can draw on map
	MAX_AOI : 1,
	// Allow fractional zoom (ie: 3.5 instead of discrete zoom levels
	// ! true can lead to problems...
	FractionalZoom : false,
	// AOI format. its value should be 'SSEGML311' or "3WSA"
	AOI_FORMAT : "SSEGML311",
	// Base layer
	BASELAYER : {
				title : "Demis World Map",
				// WMS URL
				url : "http://www2.demis.nl/worldmap/wms.asp",
				// List of requested layers
				layers :  'Bathymetry,Countries,Topography,Builtup areas,Coastlines,Rivers,Streams,Borders,Cities',
				// WMS Projection to Use (i.e "EPSG:4326")
				projection : "EPSG:4326",				
				// WMS Maximum Extent (i.e : new OpenLayers.Bounds(-180, -90,
				// 180, 90)
				maxextent : new OpenLayers.Bounds(-180, -90, 180, 90)
			}	
};
