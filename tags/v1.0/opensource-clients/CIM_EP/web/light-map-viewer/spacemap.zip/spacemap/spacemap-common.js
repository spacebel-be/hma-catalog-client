OpenLayers.ProxyHost = "/genesis-jsf/Proxy?url=";

var SpacemapCommon = {
	wmcNS : "http://www.opengis.net/context",
	openLayersContextNS : "http://openlayers.org/context",
	viewContextTag : "ViewContext",
	noWMSTag : "nonWMS",
	layerListTag : "LayerList",	
	layerTypeTag : "type",	
	layerTag : "Layer",	
	wfsStrategiesTag : "strategies",
	wfsStrategiesBBOXTag : "strategiesBBOX",
	wfsStrategiesClusterTag : "strategiesCluster",
	wfsStrategiesFixedTag : "strategiesFixed",
	wfsStrategiesFilterTag : "strategiesFilter",
	wfsStrategiesPagingTag : "strategiesPaging",
	wfsStrategiesRefreshTag : "strategiesRefresh",
	wfsStrategiesSaveTag : "strategiesSave",					
	wfsProtocolTag : "protocol",
	wfsStyleMapTag : "styleMap",
	wfsStyleMapDefaultTag : "default",
	wfsStyleMapSelectTag : "select",
	wfsStyleMapTemporaryTag : "temporary",
	wfsStyleMapDeleteTag : "delete",
	wfsStyleMapRulesTag : "rules",
	wfsStyleMapRuleTag : "rule",
	wfsStyleMapRulesSymbolizerTag : "symbolizer",
	wfsStyleMapRulesSymbolizerPointTag : "point",
	wfsStyleMapRulesSymbolizerLineTag : "line",
	wfsStyleMapRulesSymbolizerPolygonTag : "polygon",
	wfsStyleMapDefaultStyleTag : "defaultStyle",	
	visibilityTag : "visibility",
	transparentTag: "transparent",
	isBaseLayerTag: "isBaseLayer",
	numZoomLevelsTag : "numZoomLevels",
	googleType : "google",
	virtualType : "virtual",
	yahooType : "yahoo",
	wfsType : "wfs",
	
	addWMSLayer: function(specMap, layer) {
		
		if(findWMSLayer(specMap,layer["url"],layer["name"])){
			//alert("The layer is ready added.");
			//do nothing
		}else{
			var projection = this.projEPSG4326;
			if(layer["srs"] != undefined){
				projection = new OpenLayers.Projection(layer["srs"]);
			}
			var userWMS = new OpenLayers.Layer.WMS(layer.title, layer.url, {
				transparent : true,
				layers : [ layer.name ]
			}, {
				isBaseLayer : false,
				//visibility : false,
				buffer : 0,				
				projection : projection,
				displayInLayerSwitcher : true
			});
			if(layer["abstract"] != undefined){
				userWMS.description = layer["abstract"] ; 
			}
			if(layer["bbox"] != undefined){
				var bbox = layer["bbox"].split(",");
				var maxExtent = new OpenLayers.Bounds(bbox[0],bbox[1],bbox[2],bbox[3]);
				if(layer["srs"] != undefined && layer["srs"] == "EPSG:4326"){
					//alert("EPSG4326");
					maxExtent = validateBBOXBeforeConvertFrom4326To900913(bbox[0],bbox[1],bbox[2],bbox[3]);
				}				
				userWMS.maxExtent = maxExtent.transform(projection, this.projEPSG900913);
			}
			specMap.addLayers( [ userWMS ]);
		}		
	},
	projEPSG4326 : new OpenLayers.Projection("EPSG:4326"),
	projEPSG900913 : new OpenLayers.Projection("EPSG:900913"),
	srsEPSG4326 : "EPSG:4326",
	srsEPSG900913 : "EPSG:900913"
}

function exportConfig(exportContent)
{  	
	/*
		create a form
	*/	
	var submitForm = document.createElement("FORM");
	document.body.appendChild(submitForm);	
	submitForm.method = "POST";
	/*
		create an input hidden contain the wmc content
		and add it into the form
	*/
	var inputElem = document.createElement("input");
	inputElem.setAttribute("type", "hidden");
	inputElem.setAttribute("name", "content");
	inputElem.setAttribute("id", "content");
	inputElem.setAttribute("value", exportContent);
	submitForm.appendChild(inputElem);			
	/*
		Assign the form acction and submit the form
	*/
	submitForm.action= "/genesis-jsf/js/spacemap/download.jsp";	
	submitForm.submit();
}

function getNoWMSLayersXML (webMapContextText){
	var fromIdx = webMapContextText.indexOf("<" + SpacemapCommon.noWMSTag);
	var toIdx = webMapContextText.indexOf("</" + SpacemapCommon.noWMSTag + ">");
	return webMapContextText.substring(fromIdx,toIdx) + "</" + SpacemapCommon.noWMSTag + ">";
}

function generateWMC(specMap){	
	var format = new OpenLayers.Format.WMC(
		{
			'layerOptions': {buffer: 0}			
		});
	return format.write(specMap);		
}

function nonWMSLayers2WMC(layers,layerType){
	var xmlFormat = new OpenLayers.Format.XML();
	var layerList = xmlFormat.createElementNS(SpacemapCommon.openLayersContextNS,SpacemapCommon.layerListTag);
	var attributes = {
		type: layerType
	}
	xmlFormat.setAttributes(layerList,attributes);
	for(var i = 0; i < layers.length ; i++){
		var layer = xmlFormat.createElementNS(SpacemapCommon.openLayersContextNS,SpacemapCommon.layerTag);
		var hiddenValue = !layers[i].visibility;
			hiddenValue = hiddenValue ? 1 : 0;
		var attributes = {
			hidden: hiddenValue,
			visibility : true,
			transparent: layers[i].transparent,
			isBaseLayer: layers[i].isBaseLayer,
			numZoomLevels: layers[i].numZoomLevels,
			sphericalMercator:layers[i].sphericalMercator,
			type:layers[i].type,
			name:layers[i].name
		}
		xmlFormat.setAttributes(layer,attributes);
		layerList.appendChild(layer);
	}
	return layerList;	
}

function wfsLayers2WMC(wfsLayers){
	var xmlFormat = new OpenLayers.Format.XML();
	var layerList = xmlFormat.createElementNS(SpacemapCommon.openLayersContextNS,SpacemapCommon.layerListTag);
	var attributes = {
		type: SpacemapCommon.wfsType
	}
	xmlFormat.setAttributes(layerList,attributes);
	for(var i = 0; i < wfsLayers.length ; i++){
		var layer = xmlFormat.createElementNS(SpacemapCommon.openLayersContextNS,SpacemapCommon.layerTag);
		var attributes = {
			hidden: wfsLayers[i].visibility,
			name: wfsLayers[i].name,
			isBaseLayer: wfsLayers[i].isBaseLayer,
			numZoomLevels: wfsLayers[i].numZoomLevels
		}
		xmlFormat.setAttributes(layer,attributes);
		
		/*
		strategies
		*/
		if(wfsLayers[i].strategies){
			var strategiesNode = xmlFormat.createElementNS(SpacemapCommon.openLayersContextNS,SpacemapCommon.wfsStrategiesTag);
			for(var s = 0; s < wfsLayers[i].strategies.length ; s++){
				if(wfsLayers[i].strategies[s] instanceof OpenLayers.Strategy.BBOX){
					var strategiesBBOXNode = xmlFormat.createElementNS(SpacemapCommon.openLayersContextNS,SpacemapCommon.wfsStrategiesBBOXTag);
					/*var bboxAttributes = {
						bounds: wfsLayers[i].strategies[s].bounds
					}
					xmlFormat.setAttributes(strategiesBBOXNode,bboxAttributes);
					*/
					strategiesNode.appendChild(strategiesBBOXNode);
				}
				if(wfsLayers[i].strategies[s] instanceof OpenLayers.Strategy.Cluster){
					strategiesNode.appendChild(xmlFormat.createElementNS(SpacemapCommon.openLayersContextNS,SpacemapCommon.wfsStrategiesClusterTag));
				}
				if(wfsLayers[i].strategies[s] instanceof OpenLayers.Strategy.Filter){
					strategiesNode.appendChild(xmlFormat.createElementNS(SpacemapCommon.openLayersContextNS,SpacemapCommon.wfsStrategiesFilterTag));
				}
				if(wfsLayers[i].strategies[s] instanceof OpenLayers.Strategy.Fixed){
					strategiesNode.appendChild(xmlFormat.createElementNS(SpacemapCommon.openLayersContextNS,SpacemapCommon.wfsStrategiesFixedTag));
				}
				if(wfsLayers[i].strategies[s] instanceof OpenLayers.Strategy.Paging){
					strategiesNode.appendChild(xmlFormat.createElementNS(SpacemapCommon.openLayersContextNS,SpacemapCommon.wfsStrategiesPagingTag));
				}
				if(wfsLayers[i].strategies[s] instanceof OpenLayers.Strategy.Refresh){
					strategiesNode.appendChild(xmlFormat.createElementNS(SpacemapCommon.openLayersContextNS,SpacemapCommon.wfsStrategiesRefreshTag));
				}
				if(wfsLayers[i].strategies[s] instanceof OpenLayers.Strategy.Save){
					strategiesNode.appendChild(xmlFormat.createElementNS(SpacemapCommon.openLayersContextNS,SpacemapCommon.wfsStrategiesSaveTag));
				}
			}
			layer.appendChild(strategiesNode);
		}
		/*
			protocol
		*/
		var protocolNode = xmlFormat.createElementNS(SpacemapCommon.openLayersContextNS,SpacemapCommon.wfsProtocolTag);
		var protocolAttributes = {
			url: wfsLayers[i].protocol.url,
			featureType: wfsLayers[i].protocol.featureType,
			featureNS: wfsLayers[i].protocol.featureNS,
			version: wfsLayers[i].protocol.version,
			geometryName: wfsLayers[i].protocol.geometryName,
			featurePrefix: wfsLayers[i].protocol.featurePrefix,
			srsName: wfsLayers[i].protocol.srsName,
			schema: wfsLayers[i].protocol.schema,
			multi: wfsLayers[i].protocol.multi,
			outputFormat: wfsLayers[i].protocol.outputFormat
		}
		xmlFormat.setAttributes(protocolNode,protocolAttributes);
		layer.appendChild(protocolNode);
		/*
			styleMap
		*/
		if(wfsLayers[i].styleMap.styles){
			var styleMapNode = xmlFormat.createElementNS(SpacemapCommon.openLayersContextNS,SpacemapCommon.wfsStyleMapTag);			
			if(wfsLayers[i].styleMap.styles["default"]){
				var styleMapDefaultNode = xmlFormat.createElementNS(SpacemapCommon.openLayersContextNS,SpacemapCommon.wfsStyleMapDefaultTag);
				createRenderingStyle(xmlFormat, SpacemapCommon.openLayersContextNS, styleMapDefaultNode, wfsLayers[i].styleMap.styles["default"]);
				styleMapNode.appendChild(styleMapDefaultNode);						
			}
			if(wfsLayers[i].styleMap.styles["select"]){
				var styleMapSelectNode = xmlFormat.createElementNS(SpacemapCommon.openLayersContextNS,SpacemapCommon.wfsStyleMapSelectTag);
				createRenderingStyle(xmlFormat, SpacemapCommon.openLayersContextNS, styleMapSelectNode, wfsLayers[i].styleMap.styles.select);
				styleMapNode.appendChild(styleMapSelectNode);						
			}
			if(wfsLayers[i].styleMap.styles.temporary){
				var styleMapTemporaryNode = xmlFormat.createElementNS(SpacemapCommon.openLayersContextNS,SpacemapCommon.wfsStyleMapTemporaryTag);
				createRenderingStyle(xmlFormat, SpacemapCommon.openLayersContextNS, styleMapTemporaryNode, wfsLayers[i].styleMap.styles.temporary);
				styleMapNode.appendChild(styleMapTemporaryNode);						
			}
			if(wfsLayers[i].styleMap.styles["delete"]){
				var styleMapDeleteNode = xmlFormat.createElementNS(SpacemapCommon.openLayersContextNS,SpacemapCommon.wfsStyleMapDeleteTag);
				createRenderingStyle(xmlFormat, SpacemapCommon.openLayersContextNS, styleMapDeleteNode, wfsLayers[i].styleMap.styles["delete"]);
				styleMapNode.appendChild(styleMapDeleteNode);						
			}
			layer.appendChild(styleMapNode);
		}
		layerList.appendChild(layer);	
	}
	return layerList;
}

function createRenderingStyle(xmlFormatObj,contextNS,renderingStyleNode, renderingStyleObj){	
	if(renderingStyleObj.rules){
		var styleMapRulesNode = xmlFormatObj.createElementNS(contextNS,SpacemapCommon.wfsStyleMapRulesTag);
		for(var i = 0; i < renderingStyleObj.rules.length; i++){
			var styleMapRuleNode = xmlFormatObj.createElementNS(contextNS,SpacemapCommon.wfsStyleMapRuleTag);
			var rule = renderingStyleObj.rules[i];
			if(rule.symbolizer){
				var styleMapRulesSymbolizerNode = xmlFormatObj.createElementNS(contextNS,SpacemapCommon.wfsStyleMapRulesSymbolizerTag);
				if(rule.symbolizer.Point){
					var styleMapRulesSymbolizerPointNode = xmlFormatObj.createElementNS(contextNS,SpacemapCommon.wfsStyleMapRulesSymbolizerPointTag);
					xmlFormatObj.setAttributes(styleMapRulesSymbolizerPointNode,createPointAttributes(rule.symbolizer.Point));
					styleMapRulesSymbolizerNode.appendChild(styleMapRulesSymbolizerPointNode);
				}
				if(rule.symbolizer.Line){
					var styleMapRulesSymbolizerLineNode = xmlFormatObj.createElementNS(contextNS,SpacemapCommon.wfsStyleMapRulesSymbolizerLineTag);
					xmlFormatObj.setAttributes(styleMapRulesSymbolizerLineNode,createLineAttributes(rule.symbolizer.Line));
					styleMapRulesSymbolizerNode.appendChild(styleMapRulesSymbolizerLineNode);
				}
				if(rule.symbolizer.Polygon){
					var styleMapRulesSymbolizerPolygonNode = xmlFormatObj.createElementNS(contextNS,SpacemapCommon.wfsStyleMapRulesSymbolizerPolygonTag);
					xmlFormatObj.setAttributes(styleMapRulesSymbolizerPolygonNode,createPolygonAttributes(rule.symbolizer.Polygon));
					styleMapRulesSymbolizerNode.appendChild(styleMapRulesSymbolizerPolygonNode);
				}
				styleMapRuleNode.appendChild(styleMapRulesSymbolizerNode);		
				styleMapRulesNode.appendChild(styleMapRuleNode);
			}	
			renderingStyleNode.appendChild(styleMapRulesNode);
		}		
	}
	if(renderingStyleObj.defaultStyle){
		var styleMapDefaultStyleNode = xmlFormatObj.createElementNS(contextNS,SpacemapCommon.wfsStyleMapDefaultStyleTag);
		xmlFormatObj.setAttributes(styleMapDefaultStyleNode,createDefaultStyleAttributes(renderingStyleObj.defaultStyle));
		renderingStyleNode.appendChild(styleMapDefaultStyleNode);								
	}	
	
	var otherAttributes = {
		defaultsPerSymbolizer : renderingStyleObj.defaultsPerSymbolizer
	}
	xmlFormatObj.setAttributes(renderingStyleNode,otherAttributes);
	
	return renderingStyleNode;	
}

function createPointAttributes(pointValues){
	var pointAttributes = {
		strokeColor: pointValues.strokeColor,
		strokeOpacity: pointValues.strokeOpacity,
		strokeWidth: pointValues.strokeWidth,
		strokeLinecap: pointValues.strokeLinecap,
		strokeDashstyle: pointValues.strokeDashstyle,
		fillColor: pointValues.fillColor,
		fillOpacity: pointValues.fillOpacity,
		pointRadius: pointValues.pointRadius,
		externalGraphic: pointValues.externalGraphic,
		graphicWidth: pointValues.graphicWidth,
		graphicHeight: pointValues.graphicHeight,
		graphicOpacity: pointValues.graphicOpacity,
		graphicXOffset: pointValues.graphicXOffset,
		graphicYOffset: pointValues.graphicYOffset,
		rotation: pointValues.rotation,
		graphicName: pointValues.graphicName
	}
	return pointAttributes;
}

function createLineAttributes(lineValues){
	var lineAttributes = {
		strokeColor: lineValues.strokeColor,
		strokeOpacity: lineValues.strokeOpacity,
		strokeWidth: lineValues.strokeWidth,
		strokeLinecap: lineValues.strokeLinecap,
		strokeDashstyle: lineValues.strokeDashstyle
	}
	return lineAttributes;
}

function createPolygonAttributes(polygonValues){
	var polygonAttributes = {
		strokeColor: polygonValues.strokeColor,
		strokeOpacity: polygonValues.strokeOpacity,
		strokeWidth: polygonValues.strokeWidth,
		strokeLinecap: polygonValues.strokeLinecap,
		strokeDashstyle: polygonValues.strokeDashstyle,
		fillColor: polygonValues.fillColor,
		fillOpacity: polygonValues.fillOpacity
	}
	return polygonAttributes;
}

function createDefaultStyleAttributes(defaultStyleValues){
	var defaultStyleAttributes = {
		strokeColor: defaultStyleValues.strokeColor,
		strokeOpacity: defaultStyleValues.strokeOpacity,
		strokeWidth: defaultStyleValues.strokeWidth,
		strokeLinecap: defaultStyleValues.strokeLinecap,
		strokeDashstyle: defaultStyleValues.strokeDashstyle,
		fillColor: defaultStyleValues.fillColor,
		fillOpacity: defaultStyleValues.fillOpacity
	}
	return defaultStyleAttributes;
}


function findWMSLayer(specMap, serverUrl, layerName){	
	var found = false;
	var layersList = specMap.layers;
	for(var i = 0; i < layersList.length ; i++){
		if(layersList[i] instanceof OpenLayers.Layer.WMS){
			if(serverUrl == layersList[i].url && layerName == layersList[i].params.LAYERS){
				found = true;
				break;
			}			
		}		
	}
	return found;
}

function loadLayersFromWMSUrl(){	
	var wmsURL = document.getElementById("wmsUrl2GetCapabilities").value;
	var request = OpenLayers.Request.issue({
		url: wmsURL,
		/*params: {
			SERVICE: "WMS",
			VERSION: "1.1.1",
			REQUEST: "GetCapabilities"
		},*/
		headers: {
			"Content-Type": "text/xml"
		},
		success: function(request) {
			var doc;
			try{
				doc = request.responseXML;		
				if (!doc || !doc.documentElement) {
					doc = request.responseText;
				}
			}catch(err){
				doc = request.responseText;
			}										
			
			generateLayerList(doc,wmsURL);
		},
		failure: function() {
			OpenLayers.Console.error.apply(OpenLayers.Console, arguments);
		}/*,
		callback: handler*/
	});		
}

/*function handler(request) {
	alert(OpenLayers.Util.getParameterString(request));
	// if the response was XML, try the parsed doc
	alert(request.responseXML);
	// otherwise, you've got the response text
	alert(request.responseText);
	// and don't forget you've got status codes
	alert(request.status);
	// and of course you can get headers
	alert(request.getAllResponseHeaders());
	// etc.
}*/

function generateLayerList(doc,serverURL){
	var  wmsCapabilities = new OpenLayers.Format.WMSCapabilities();
	var  capabilities = wmsCapabilities.read(doc);	
	var mainDiv = document.getElementById("layersListContainer");
	// reset layersListContainer
	mainDiv.innerHTML = "";
	var numOflayers = capabilities.capability.layers.length;
	
	var getmapURL = capabilities.capability.request.getmap.href;
	
	if(getmapURL && isUrl(getmapURL) ){
		if(getmapURL.indexOf("?") > 0){
			serverURL = getmapURL.substring(0,getmapURL.indexOf("?"));
		}else{
			serverURL = getmapURL;	
		}
	}else{
		serverURL = serverURL.substring(0,serverURL.indexOf("?"));
	}
	
	for(var i=0; i<numOflayers; i++){
		var layer = capabilities.capability.layers[i];
		createLayerInputs(mainDiv,i,serverURL,layer);
		//break;
	}
	
	if(capabilities.capability.layers.length > 0){				
		var addLayerButton = document.createElement("input");
		addLayerButton.id = "addLayersButton";
		addLayerButton.name = "addLayers";
		addLayerButton.type = "button";
		addLayerButton.value = "Add Layer(s)";
		addLayerButton.onclick =  function () {addLayersFromCapabilities2Map(serverURL,numOflayers)};
		mainDiv.appendChild(addLayerButton);
	}		
} 

function isUrl(url) {
	var regexp = /(http):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/
	return regexp.test(url);
}

function createLayerInputs(mainDiv,index,wmsUrl,specLayer){
	
	var inputElem = createInputElement("layerFromCapabilities-" + index,"checkbox",specLayer.name);
	/*
		disable the existing layer
	*/
	if(findWMSLayer(SpaceMap.spacemap,wmsUrl,specLayer.name)){
		inputElem.disabled = true;
	}
	
	var rowDiv = document.createElement("div");	
	rowDiv.style.position = "relative";
	mainDiv.appendChild(rowDiv);
	
	var labelSpan = document.createElement("span");
	labelSpan.className = "text-label";
	labelSpan.innerHTML = specLayer.title;
		
	var descriptionSpan = document.createElement("span");
	descriptionSpan.id = "layer-description-" + index;
	descriptionSpan.className = "text-label";
	descriptionSpan.style.display = "none";
	
	var getLegendGraphicUrl = wmsUrl 
			+ "?REQUEST=GetLegendGraphic&SERVICE=WMS&VERSION=1.1.1&LAYER=" 
			+ specLayer.name + "&FORMAT=image/png&WIDTH=150";
	var legendInnerHTML = ""
			+ "<img style=\"display:none\" src=\""
			+ getLegendGraphicUrl
			+ "\" onload=\"this.style.display = 'inline'\" alt=\"\" onerror=\"this.src='"
			+ OpenLayers.Util.getImagesLocation()
			+ "blank.gif" + "'\" />";
							
	rowDiv.appendChild(inputElem);	
	rowDiv.appendChild(labelSpan);	
	
	var toggleButton = document.createElement("img");
	toggleButton.setAttribute("id", "layer-description-toggle-" + index);
	toggleButton.src = OpenLayers.Util.getImagesLocation() + "expand.png";
	toggleButton.style.cursor = "pointer";
	toggleButton.style.position = "relative";
	toggleButton.style.top = "0";
	//toggleButton.style.right = "0";
	//toggleButton.style.padding = "5px";
	toggleButton.onclick =  function () {
		var span = OpenLayers.Util.getElement("layer-description-" + index);
		var button = OpenLayers.Util.getElement("layer-description-toggle-" + index);
		if (span && button) {
			var display = span.style.display;
			if (display == "block") {
				span.style.display = "none";
				button.src = OpenLayers.Util
						.getImagesLocation()
						+ "expand.png";
			} else {
				span.style.display = "block";
				button.src = OpenLayers.Util
						.getImagesLocation()
						+ "collapse.png";
			}
		}
	}

	// create hidden input to store title	
	rowDiv.appendChild(createInputElement("layerFromCapabilities-title-" + index,"hidden",specLayer.title));
	
	if(specLayer["abstract"]){
		/*
			display abstract
		*/		
		legendInnerHTML = specLayer["abstract"] + "<br/>" + legendInnerHTML;
		// create hidden input to store abstract
		rowDiv.appendChild(createInputElement("layerFromCapabilities-abstract-" + index,"hidden",specLayer["abstract"]));
	}
	if(specLayer["bbox"]){
		var bbox = getWMSLayerBBOX(specLayer["bbox"]) 		
		if(bbox){
			var bboxObj = validateBBOXBeforeConvertFrom4326To900913(bbox[0],bbox[1],bbox[2],bbox[3]);			
			rowDiv.appendChild(createInputElement("layerFromCapabilities-bbox-" + index,"hidden",bboxObj));
		}
	}
	
	descriptionSpan.innerHTML = legendInnerHTML;
	
	rowDiv.appendChild(toggleButton);
	rowDiv.appendChild(descriptionSpan);
	
	var breakLineElem = document.createElement("br");
	rowDiv.appendChild(breakLineElem);	
	
}

function getWMSLayerBBOX(bbox){
	var bboxValue = undefined;
	for (var srs in bbox) {
		/**
			Only accept the bbox of EPSG:4326
		*/
		if(srs == SpacemapCommon.srsEPSG4326){
			bboxValue = bbox[srs]["bbox"];			
			break;
		}
	}
	return bboxValue;
}
/**
	check long/lat to prevent infinity when converting to EPSG:900913
*/
function validateBBOXBeforeConvertFrom4326To900913(left,bottom,right,top) {	
	if(left < -179){
		left = -179;
	}					
	if(bottom < -85){
		bottom = -67;
	}					
	if(right > 179){
		right = 179;
	}
	if(top > 85){
		top = 85;
	}	
	return new OpenLayers.Bounds(left,bottom,right,top);
}

function createInputElement(id,type,value){
	var inputElem = document.createElement("input");
	inputElem.id = id;
	inputElem.name = id;
	inputElem.type = type;	
	inputElem.value = value;
	return inputElem;
}
function addLayersFromCapabilities2Map(wmsUrl,numOflayers){		
	var numOfAddedLayers = 0;
	for(var i=0; i< numOflayers; i++)
	{
		var layerCheckbox = document.getElementById("layerFromCapabilities-" + i);
		if(layerCheckbox.checked){
			var layer = {};
			layer["url"] = wmsUrl;
			layer["name"] = layerCheckbox.value;
			var layerTitle = document.getElementById("layerFromCapabilities-title-" + i);
			if(layerTitle){
				layer["title"] = layerTitle.value;
			}
			var layerAbstract = document.getElementById("layerFromCapabilities-abstract-" + i);
			if(layerAbstract){
				layer["abstract"] = layerAbstract.value;
			}
			var layerBBOX = document.getElementById("layerFromCapabilities-bbox-" + i);
			if(layerBBOX){
				layer["bbox"] = layerBBOX.value;
			}
			SpacemapCommon.addWMSLayer(SpaceMap.spacemap,layer);
			//SpaceMapUtils.addWMSLayer(wmsUrl,layer);
			
			numOfAddedLayers++;
			layerCheckbox.checked = false;
			layerCheckbox.disabled = true;					
		}				
	} 
	if(numOfAddedLayers > 0){
		alert(numOfAddedLayers + " layer(s) has been added.");
	}else{
		alert("Please select layer to be added.");
	}
}

function getNoWMSLayers(noWMSLayersXML) {	
	var xmlFormat = new OpenLayers.Format.XML();
	var noWMSLayersDoc = xmlFormat.read(noWMSLayersXML);
	var contextNS = SpacemapCommon.openLayersContextNS;
	var hasSelectedLayer = false;
	var results = {
		noWMSLayersList: null,
		selectedLayer: null	
	};		
	results.noWMSLayersList = new Array();		
	
	var layerListNodes = xmlFormat.getElementsByTagNameNS(noWMSLayersDoc, contextNS, SpacemapCommon.layerListTag);
	for(var i = 0; i < layerListNodes.length; i++) {
		var layerListNode = layerListNodes[i];
		var layerType = layerListNode.getAttribute(SpacemapCommon.layerTypeTag);
		var layerNodes = xmlFormat.getElementsByTagNameNS(layerListNode, contextNS, SpacemapCommon.layerTag);
		for(var l = 0; l < layerNodes.length; l++) {
			var layerNode = layerNodes[l];
			var options = convertXMLAttributes2OpenlayersOptions(layerNode.attributes);
			//alert(OpenLayers.Util.getParameterString(options));
			var layerObj = null;
			if(options["showOnLayerList"] == true){				
				if(layerType == SpacemapCommon.yahooType){
					layerObj = new OpenLayers.Layer.Yahoo(options.name,options);
				}
				if(layerType == SpacemapCommon.virtualType){
					layerObj = new OpenLayers.Layer.VirtualEarth(options.name,options);
				}
				if(layerType == SpacemapCommon.googleType){					
					layerObj = new OpenLayers.Layer.Google(options.name,options);
				}
				if(layerObj){
					if(!hasSelectedLayer && layerObj.visibility){
						hasSelectedLayer = true;
						results.selectedLayer = layerObj;
					}else{
						layerObj.visibility = true;
					}
				}
			}			
			if(layerType == SpacemapCommon.wfsType){
				layerObj = createWFSLayer(layerNode);
			}
			if(layerObj){
				results.noWMSLayersList.push(layerObj);	
			}	
		}
	}		
	return results;	
}

function createWFSLayer(wfsLayerNode) {
	var xmlFormat = new OpenLayers.Format.XML();	
	var strategies, protocol, styleMap;
	var wfsOptions = {};
	var strategiesNodes = xmlFormat.getElementsByTagNameNS(wfsLayerNode, SpacemapCommon.openLayersContextNS, SpacemapCommon.wfsStrategiesTag);
	if(strategiesNodes.length > 0){
		strategies = getWFSStrategies(strategiesNodes[0]);
		wfsOptions["strategies"] = strategies;
	}
	
	var protocolNodes = xmlFormat.getElementsByTagNameNS(wfsLayerNode, SpacemapCommon.openLayersContextNS, SpacemapCommon.wfsProtocolTag);
	if(protocolNodes.length > 0){
		protocol = convertXMLAttributes2OpenlayersOptions(protocolNodes[0].attributes);
		wfsOptions["protocol"] = new OpenLayers.Protocol.WFS(protocol);
	}
	
	var styleMapNodes = xmlFormat.getElementsByTagNameNS(wfsLayerNode, SpacemapCommon.openLayersContextNS, SpacemapCommon.wfsStyleMapTag);
	if(styleMapNodes.length > 0){
		styleMap = getWFSStyleMap(styleMapNodes[0]);
		wfsOptions["styleMap"] = styleMap;
	}	
	wfsOptions["projection"] = SpacemapCommon.projEPSG4326;
	
	var options = convertXMLAttributes2OpenlayersOptions(wfsLayerNode.attributes);		
	var wfsLayer = new OpenLayers.Layer.Vector(
		options.name,			
		wfsOptions
	);	
	wfsLayer.setVisibility(options.visibility);	
	
	return wfsLayer;
}

function getWFSStrategies(strategiesNode){
	var xmlFormat = new OpenLayers.Format.XML();
	var strategies = new Array();
	var bboxNode = xmlFormat.getElementsByTagNameNS(strategiesNode, SpacemapCommon.openLayersContextNS, SpacemapCommon.wfsStrategiesBBOXTag);
	if(bboxNode.length > 0){
		var sBounds = bboxNode[0].attributes.getNamedItem("bounds");
		if(sBounds){
			var options = {
				bounds: new OpenLayers.Bounds(sBounds.value)
			}
			strategies.push(new OpenLayers.Strategy.BBOX(options));	
		}else{
			strategies.push(new OpenLayers.Strategy.BBOX());
		}
		
	}
	if(xmlFormat.getElementsByTagNameNS(strategiesNode, SpacemapCommon.openLayersContextNS, SpacemapCommon.wfsStrategiesFixedTag).length > 0){
		strategies.push(new OpenLayers.Strategy.Fixed());
	}
	if(xmlFormat.getElementsByTagNameNS(strategiesNode, SpacemapCommon.openLayersContextNS, SpacemapCommon.wfsStrategiesClusterTag).length > 0){
		strategies.push(new OpenLayers.Strategy.Cluster());
	}
	if(xmlFormat.getElementsByTagNameNS(strategiesNode, SpacemapCommon.openLayersContextNS, SpacemapCommon.wfsStrategiesFilterTag).length > 0){
		strategies.push(new OpenLayers.Strategy.Filter());
	}
	if(xmlFormat.getElementsByTagNameNS(strategiesNode, SpacemapCommon.openLayersContextNS, SpacemapCommon.wfsStrategiesPagingTag).length > 0){
		strategies.push(new OpenLayers.Strategy.Paging());
	}
	if(xmlFormat.getElementsByTagNameNS(strategiesNode, SpacemapCommon.openLayersContextNS, SpacemapCommon.wfsStrategiesRefreshTag).length > 0){
		strategies.push(new OpenLayers.Strategy.Refresh());
	}
	if(xmlFormat.getElementsByTagNameNS(strategiesNode, SpacemapCommon.openLayersContextNS, SpacemapCommon.wfsStrategiesSaveTag).length > 0){
		strategies.push(new OpenLayers.Strategy.Save());
	}
	return strategies;
}

function getWFSStyleMap(styleMapNode){
	var xmlFormat = new OpenLayers.Format.XML();
	var defaultNodes = xmlFormat.getElementsByTagNameNS(styleMapNode,SpacemapCommon.openLayersContextNS,SpacemapCommon.wfsStyleMapDefaultTag);
	var selectNodes = xmlFormat.getElementsByTagNameNS(styleMapNode,SpacemapCommon.openLayersContextNS,SpacemapCommon.wfsStyleMapSelectTag);
	var temporaryNodes = xmlFormat.getElementsByTagNameNS(styleMapNode,SpacemapCommon.openLayersContextNS,SpacemapCommon.wfsStyleMapTemporaryTag);
	var deleteNodes = xmlFormat.getElementsByTagNameNS(styleMapNode,SpacemapCommon.openLayersContextNS,SpacemapCommon.wfsStyleMapDeleteTag);
	var styleMapOptions = {};
	if(defaultNodes.length > 0){
		styleMapOptions["default"] = getRenderingStyleMap(defaultNodes[0]);
	}
	if(selectNodes.length > 0){
		styleMapOptions["select"] = getRenderingStyleMap(selectNodes[0]);
	}
	if(temporaryNodes.length > 0){
		styleMapOptions["temporary"] = getRenderingStyleMap(temporaryNodes[0]);
	}
	if(deleteNodes.length > 0){
		styleMapOptions["delete"] = getRenderingStyleMap(deleteNodes[0]);
	}
	return new OpenLayers.StyleMap(styleMapOptions);
}

function getRenderingStyleMap(renderingStyleNode){
	var xmlFormat = new OpenLayers.Format.XML();
	var renderingOptions = convertXMLAttributes2OpenlayersOptions(renderingStyleNode.attributes);
	var ruleNodes = xmlFormat.getElementsByTagNameNS(renderingStyleNode,SpacemapCommon.openLayersContextNS,SpacemapCommon.wfsStyleMapRuleTag);	
	if(ruleNodes.length > 0){
		var rulesList = new Array();
		for(var i = 0; i < ruleNodes.length; i++)	{			
			var symbolizerNodes = xmlFormat.getElementsByTagNameNS(ruleNodes[i],SpacemapCommon.openLayersContextNS,SpacemapCommon.wfsStyleMapRulesSymbolizerTag);
			var symbolizerOptions = {};	
			//if(symbolizerNodes.length > 0){
				var pointNodes = xmlFormat.getElementsByTagNameNS(symbolizerNodes[0],SpacemapCommon.openLayersContextNS,SpacemapCommon.wfsStyleMapRulesSymbolizerPointTag);
				if(pointNodes.length > 0){
					symbolizerOptions["Point"] = convertXMLAttributes2OpenlayersOptions(pointNodes[0].attributes);
				}			
				var lineNodes = xmlFormat.getElementsByTagNameNS(symbolizerNodes[0],SpacemapCommon.openLayersContextNS,SpacemapCommon.wfsStyleMapRulesSymbolizerLineTag);
				if(lineNodes.length > 0){
					symbolizerOptions["Line"] = convertXMLAttributes2OpenlayersOptions(lineNodes[0].attributes);
				}
				var polygonNodes = xmlFormat.getElementsByTagNameNS(symbolizerNodes[0],SpacemapCommon.openLayersContextNS,SpacemapCommon.wfsStyleMapRulesSymbolizerPolygonTag);
				if(polygonNodes.length > 0){
					symbolizerOptions["Polygon"] = convertXMLAttributes2OpenlayersOptions(polygonNodes[0].attributes);
				}
			//}
			rulesList.push(new OpenLayers.Rule({symbolizer:symbolizerOptions}));
		}
		return new OpenLayers.Style(null, {rules:rulesList});
	}else{
		var defaultStyleNodes = xmlFormat.getElementsByTagNameNS(renderingStyleNode,SpacemapCommon.openLayersContextNS,SpacemapCommon.wfsStyleMapDefaultStyleTag);
		if(defaultStyleNodes.length > 0){
			return new OpenLayers.Style(convertXMLAttributes2OpenlayersOptions(defaultStyleNodes[0].attributes));
		}
	}
	return undefined;
}

function convertXMLAttributes2OpenlayersOptions(attributes){
	var options = {};
	for(var j = 0; j < attributes.length; j++){
		var attValue = attributes.item(j).value;
		if(attValue == "true"){
			attValue = true;
		}else if(attValue == "false"){
			attValue = false;
		}else if(!isNaN(attValue)){
			attValue = Number(attValue);
		}
		var optionName = attributes.item(j).name;
		if(attributes.item(j).name == "hidden"){
			optionName = "visibility";
			if(isNaN(attValue)){
				attValue = !attValue;
			}else{
				attValue = (attValue == 1) ? false : true;
			}		
		}
		if(attributes.item(j).name == "visibility"){
			optionName = "showOnLayerList";
		}
		options[optionName] = attValue;
	}
	return options;
}


