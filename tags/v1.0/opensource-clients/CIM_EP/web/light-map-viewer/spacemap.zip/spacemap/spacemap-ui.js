/**
 * SpaceMap-UI includes all useful function for User Inteface functionalities
 * The library wraps any UI framework (if any)
 */

var SpaceMapUI = {
	// Display a alert message in a dialog box
	alert : function(message) {
		alert(message);
	},
	/**
	 * simplepopup Display a simple popup with given content (TODO test) Remove
	 * the created feature when closed
	 */

	simplepopup : function(title, feature, popupContentHTML) {
		feature.closeBox = true;
		feature.popupClass = OpenLayers.Class(OpenLayers.Popup.Anchored, {
			'autoSize' : true
		});
		;
		feature.data.popupContentHTML = popupContentHTML;
		feature.data.overflow = "auto";
		feature.popup.on({
			close : function() {
				feature.layer.removeFeatures([ feature ]);
			}
		});
		feature.popup.show();
	},
	/**
	 * Display a pop up info when a feature is selected Unselected the feature
	 * when popup is closed
	 * 
	 * @param title
	 * @param feature
	 * @param popupContentHTML
	 */
	featureinfopopup : function(title, feature, popupContentHTML, selectControl) {
		feature.closeBox = true;
		feature.popupClass = OpenLayers.Class(OpenLayers.Popup.Anchored, {
			'autoSize' : true
		});
		;
		feature.data.popupContentHTML = popupContentHTML;
		feature.data.overflow = "auto";
		feature.popup.on({
			close : function() {
				if (OpenLayers.Util.indexOf(feature.layer.selectedFeatures,
						feature) > -1) {
					selectControl.unselect(feature);
				}
			}
		});
		feature.popup.show();
	}
};