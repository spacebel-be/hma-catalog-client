/**
 * SpaceMap --------
 * 
 * @author Spacebel - Christophe No�l
 * @date 2012 March This library creates a map with a toolbar. Main function:
 *       init()
 */

var SpaceMap = {
	// The (main) OpenLayers Map
	spacemap : null,
	// Input / AOI layer
	vlayer : null,
	// Result layer
	rlayer : null,
	// Selection controller of the result layer
	selectControl : null,
	/**
	 * Global variable defaults
	 */
	// TODO comment
	notshoh : false,
	// Current # of displayed AOI
	aoi_items : 0,
	// Current resolution
	cresolution : 20000,
	// TODO comment
	current_wmsformat : "image/png",
	current_wmsversion : "1.1.0",
	current_wmscrs : "EPSG:4326",
	current_wfsformat : "image/png",
	current_wfsversion : "1.1.0",
	current_wfscrs : "EPSG:4326",
	current_ws : "WMS",
	/**
		these variables are used to visible/invisible data layers
	*/
	noneLayer : null,
	currentDataLayerElements : null,
	currentBaseLayerElement : null,
	
	/**
	 * Function init() Map Initialization: should be called by JQuery.init
	 */
	init : function(wmcContext) {
		// Defines a proxy for allowing XML access to Javascript (see OpenLayers
		// doc)
		OpenLayers.ProxyHost = "/genesis-jsf/Proxy?url=";
		OpenLayers.ImgPath = "http://js.mapbox.com/theme/dark/";
		// Used projections definitions
		//Proj4js.defs["EPSG:4326"] = "+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs";
		//Proj4js.defs["EPSG:900913"] = "+proj=merc +a=6378137 +b=6378137 +lat_ts=0.0 +lon_0=0.0 +x_0=0.0 +y_0=0 +k=1.0 +units=m +nadgrids=@null +no_defs";
		//Proj4js.defs["EPSG:31370"] = "+title=Lambert belge +proj=lcc +lat_1=51.16666723333334 +lat_2=49.83333389999999 +lat_0=90 +lon_0=4.367486666666666 +x_0=150000.013 +y_0=5400088.438 +ellps=intl +towgs84=-99.1,53.3,-112.5,0.419,-0.83,1.885,-1.0 +units=m +no_defs";

		// Calculate viewer width at runtime if VIEWER_WIDTH=0 (means autofit)
		if (!(SpaceMapSettings.VIEWER_WIDTH > 0) && document.getElementById("spacemap-container") != null) {
			SpaceMapSettings.VIEWER_WIDTH = document
					.getElementById("spacemap-container").offsetWidth;
		}

		/*
			Map Default Settings
		*/		
		var maxExtent = new OpenLayers.Bounds(-180, -90, 180, 90),			
			maxResolution = 10;
		
		var options = {
			projection: new OpenLayers.Projection(SpaceMapSettings.SERVICE_PROJECTION),
			displayProjection: new OpenLayers.Projection(SpaceMapSettings.SERVICE_PROJECTION),
			units: "m",
			numZoomLevels: 18,
			//allOverlays: true,
			maxResolution: maxResolution,
			maxExtent: maxExtent			
		};	
					
		if(wmcContext != null){
			try 
         	{ 				
				if(this.spacemap){
					//alert("map exist. Destroy it.");
					this.spacemap.destroy();
				}
  			} 
  			catch(e){}//alert(e);}
			
			this.spacemap = new OpenLayers.Map("spacemap", options);
			/*
				create a blank base layer
			*/			
			//this.noneLayer = new OpenLayers.Layer("None",{isBaseLayer: true});
			//this.noneLayer = SpaceMapSettings.BASELAYER;
			/*
				get all google, yahoo, bing, wfs layers
			*/						
			var layers = new Array();
			var hasBaseLayer = false;
			var defaultBaseLayer = null;
			for(var i = 0; i < wmcContext.layersContext.length ; i++){
				var layCtx = wmcContext.layersContext[i];				
				var tmpLayer = new OpenLayers.Layer.WMS(
					layCtx.title,layCtx.url,
					{
						layers: layCtx.name,
						projection: new OpenLayers.Projection("EPSG:4326")	
					}
				);
				tmpLayer.queryable = layCtx.queryable;
				if(layCtx.maxExtent){					
					tmpLayer.maxExtent = layCtx.maxExtent;
				}				
				if(layCtx.numZoomLevels != undefined){
					tmpLayer.numZoomLevels = layCtx.numZoomLevels;
				}				
				
				tmpLayer.isBaseLayer = layCtx.isBaseLayer;
				tmpLayer.visibility = layCtx.visibility;
				
				if(layCtx.displayInLayerSwitcher != undefined){
					tmpLayer.displayInLayerSwitcher = layCtx.displayInLayerSwitcher;
				}
				if(layCtx.units != undefined){
					tmpLayer.units = layCtx.units;
				}
				if(layCtx.opacity != undefined){
					tmpLayer.opacity = layCtx.opacity;
				}
				if(layCtx.singleTile != undefined){
					tmpLayer.singleTile = layCtx.singleTile;
				}
				if(layCtx["abstract"] != undefined){
					tmpLayer.description = layCtx["abstract"] ; 
				}	
				if(layCtx.transparent != undefined){
					tmpLayer.params.TRANSPARENT = layCtx.transparent;
				}
				
				if(tmpLayer.isBaseLayer && !hasBaseLayer){
					hasBaseLayer = true;
					defaultBaseLayer = tmpLayer;
				}else{
					layers.push(tmpLayer);
				}
				//alert(tmpLayer.div.id);
			}
			/*/
				add blank base layer to the map
			*/
			if(hasBaseLayer){
				this.noneLayer = defaultBaseLayer;
			}else{
				this.noneLayer = new OpenLayers.Layer.WMS(
					SpaceMapSettings.BASELAYER["title"],SpaceMapSettings.BASELAYER["url"],
					{
						layers: SpaceMapSettings.BASELAYER["layers"],						
						projection: new OpenLayers.Projection(SpaceMapSettings.BASELAYER["projection"])	
					}
				);
				this.noneLayer.isBaseLayer = true;
				this.noneLayer.maxExtent = SpaceMapSettings.BASELAYER["maxextent"];				
			}	
			layers.push(this.noneLayer);
			this.spacemap.addLayers(layers);			
			this.spacemap.setBaseLayer(this.noneLayer);
		}else{	
			this.spacemap = new OpenLayers.Map("spacemap", options);	
			this.prepareBaseLayers();
		}		
		/* add default controls */
		this.addDefaultControls();
		
		this.prepareUserLayers();
		this.selectControl = new OpenLayers.Control.SelectFeature(
				SpaceMap.rlayer, {
					onSelect : SpaceMap.onSelectAction,
					onUnselect : SpaceMap.onFeatureUnselect
				});

		// Controls definition
		var container = document.getElementById("spacepanel");
		var zoomMaxControl = new OpenLayers.Control.ZoomToMaxExtent({
			title : "Zoom to max extent",
			displayClass : "actionFull",
			type : OpenLayers.Control.TYPE_BUTTON
		});
		var dragpanControl = new OpenLayers.Control.DragPan({
			title : 'Navigate in the map',
			displayClass : "actionDragPan"
		});
		var zoominControl = new OpenLayers.Control.ZoomBox({
			title : "Zoom in selected area",
			displayClass : "actionZoom"
		});
		var zoomoutControl = new OpenLayers.Control.ZoomBox({
			out : true,
			title : "Zoom out of selected area",
			displayClass : "actionZoomOut"
		});
		var navhistoryControl = new OpenLayers.Control.NavigationHistory();
		// map.addControl(navhistoryControl);
		navhistoryControl.previous.displayClass = "actionPrevious";
		navhistoryControl.previous.title = "Previous view";
		navhistoryControl.next.displayClass = "actionNext";
		navhistoryControl.next.div = container;
		navhistoryControl.next.title = "Next view";
		this.spacemap.addControl(navhistoryControl);

		polyOptions = {
			sides : 4,
			irregular : true,
			title : 'Draw AOI'
		};
		var drawFeatureControl = new OpenLayers.Control.DrawFeature(
				this.vlayer, OpenLayers.Handler.RegularPolygon, {
					handlerOptions : polyOptions,
					title : "Draw AOI",
					displayClass : "actionAOI"
				});
		var removeControl = new OpenLayers.Control({
			title : "Remove AOI",
			displayClass : "actionRemove",
			trigger : function() {
				SpaceMap.spacemap.getLayersByName('AOI')[0].destroyFeatures();
				SpaceMap.spacemap.getLayersByName('AOI')[0].redraw();
				document.getElementById('olAOI').value = "";
				SpaceMap.aoi_items = 0;
			},
			type : OpenLayers.Control.TYPE_BUTTON
		});

		var movControl = new OpenLayers.Control.ModifyFeature(this.vlayer, {
			title : "Modify AOI",
			displayClass : "actionModify"
		});
		movControl.mode = OpenLayers.Control.ModifyFeature.RESHAPE;
		movControl.mode |= OpenLayers.Control.ModifyFeature.RESIZE;
		movControl.mode |= OpenLayers.Control.ModifyFeature.DRAG;
		fiControl = new OpenLayers.Control.SelectFeature(SpaceMap.rlayer, {
			onSelect : SpaceMap.onSelectAction,
			onUnselect : SpaceMap.onFeatureUnselect,
			title : "Show feature info",
			displayClass : "actionFI"
		});
		// ToolBar

		zb = new OpenLayers.Control.ZoomBox(
				{
					title : "Zoom box: Selecting it you can zoom on an area by clicking and dragging.",
					displayClass : "actionZoom"
				});
		var panel = new OpenLayers.Control.Panel({
			defaultControl : zb,
			div : container
		});
		// TODO
		// Only draw AOI toolbar if the client specific map init is not defined
		// if (typeof mapInit != 'function') {
				
		var addLayersControl = new OpenLayers.Control({
			title : "Add Layers",
			displayClass : "addLayers",
			trigger : function() {				
				openAddLayersWindow();
			},
			type : OpenLayers.Control.TYPE_BUTTON
		});
		
		var exportConfigControl = new OpenLayers.Control({
			title : "Export map configuration to Web Map Context document",
			displayClass : "exportLayers",
			trigger : function() {				
				exportConfig(generateWMC(SpaceMap.spacemap));
			},
			type : OpenLayers.Control.TYPE_BUTTON
		});
		
		panel.addControls([ zoomMaxControl, dragpanControl, zoominControl,
				zoomoutControl, navhistoryControl.previous,
				navhistoryControl.next, drawFeatureControl, removeControl,
				movControl, exportConfigControl

		]);
		this.spacemap.addControl(panel);

		this.spacemap.addControl(this.selectControl);
		graticuleCtl = new OpenLayers.Control.Graticule({
			numPoints : 2,
			labelled : true,
			displayInLayerSwitcher : false,
			visible : false
		});
		this.spacemap.addControl(graticuleCtl);

		// Add the customed WMS Libraries
		if (typeof addWMSLibraries != 'undefined') {
			addWMSLibraries();
		}

		// Allow the fractional zoom with zooming control.
		this.spacemap.fractionalZoom = SpaceMapSettings.FractionalZoom;
		// check if the following could be added directly in controls options
		var nav = new OpenLayers.Control.NavigationHistory();
		// parent control must be added to the map
		this.spacemap.addControl(nav);
		if(wmcContext != null){			
			var centerconverted = SpaceMapSettings.CENTERMAP.transform(
			new OpenLayers.Projection("EPSG:4326"), this.spacemap
						.getProjectionObject());
			this.spacemap.setCenter(centerconverted, SpaceMapSettings.DEFAULT_ZOOM);						
		}else{
			centerconverted = SpaceMapSettings.CENTERMAP.transform(
			new OpenLayers.Projection("EPSG:4326"), this.spacemap
						.getProjectionObject());
			this.spacemap.setCenter(centerconverted, SpaceMapSettings.DEFAULT_ZOOM);
		}		
		
		// var wmslibrary = SPBV_WMSLIB;
		// Load the client mapInit function if defined
		if (typeof mapInit == 'function') {
			mapInit();
		}

	},
	prepareBaseLayers : function() {
		/**
		 * Definition of Base layers definition: - First, set the DEFAULT base
		 * layer - Add the selected other Base layers
		 */
		var NasaLayer = new OpenLayers.Layer.WMS("Nasa",
				"http://maps.opengeo.org/geowebcache/service/wms", {
					layers : "bluemarble"
				});
		var DemisLayer = new OpenLayers.Layer.WMS(
				"Demis",
				"http://www2.demis.nl/worldmap/wms.asp",
				{
					layers : 'Bathymetry,Countries,Topography,Builtup areas,Coastlines,Rivers,Streams,Borders,Cities'
				}, {
					projection : new OpenLayers.Projection("EPSG:4326"),
					displayProjection : new OpenLayers.Projection("EPSG:4326"),
					maxResolution : 10,
					maxExtent : new OpenLayers.Bounds(-180, -90, 180, 90),
					numZoomLevels : 16
				});
		var GoogleHybridLayer = new OpenLayers.Layer.Google("Google Hybrid", {
			type : google.maps.MapTypeId.HYBRID,
			// maxResolution : 10,
			// numZoomLevels : 16,
			visibility : false
		});

		var GooglePhysicalLayer = new OpenLayers.Layer.Google(
				"Google Physical", {
					type : google.maps.MapTypeId.TERRAIN,
					visibility : false
				// maxResolution : 10,
				// numZoomLevels : 16
				});
		var MetaCartaLayer = new OpenLayers.Layer.WMS("Metacarta",
				"http://vmap0.tiles.osgeo.org/wms/vmap0", {
					layers : 'basic'
				}, {
					projection : new OpenLayers.Projection("EPSG:4326"),
					displayProjection : new OpenLayers.Projection("EPSG:4326"),
					maxResolution : 10,
					maxExtent : new OpenLayers.Bounds(-180, -90, 180, 90),
					numZoomLevels : 16
				});
		var BelgiumLayer = new OpenLayers.Layer.WMS(
				"Belgique",
				"http://projects-eu2.erdas.com:80/erdas-apollo/vector/BELGIQUE",
				{
					layers : [ 'BEL_adm0', 'BEL_adm1', 'BEL_adm2', 'waterways' ]
				}, {
					projection : new OpenLayers.Projection("EPSG:31370"),
					displayProjection : new OpenLayers.Projection("EPSG:4326"),
					maxExtent : new OpenLayers.Bounds(-20037508.34,
							-20037508.34, 20037508.34, 20037508.34),
					numZoomLevels : 16
				});
		var WalLayer = new OpenLayers.Layer.WMS(
				"Wallonie",
				"http://cartopro1.wallonie.be:80/WMS/com.esri.wms.Esrimap/PPNC",
				{
					layers : [ '1', '2', '3', '4', '5', '6' ]
				}, {
					projection : new OpenLayers.Projection("EPSG:31370"),
					displayProjection : new OpenLayers.Projection("EPSG:4326"),
					maxResolution : 20000,
					maxExtent : new OpenLayers.Bounds(-20037508.34,
							-20037508.34, 20037508.34, 20037508.34),
					numZoomLevels : 16
				});
		var YahooLayer = new OpenLayers.Layer.Yahoo("Yahoo");

	

		/**
		 * 
		 * var BingAerialLayer = new OpenLayers.Layer.VirtualEarth("Bing
		 * Aerial", { type : VEMapStyle.Aerial, numZoomLevels : 16 }); var
		 * BingHybridLayer = new OpenLayers.Layer.VirtualEarth("Bing Hybrid", {
		 * type : VEMapStyle.Hybrid, numZoomLevels : 16 }); var BingStreetLayer =
		 * new OpenLayers.Layer.VirtualEarth("Bing Street", { type :
		 * VEMapStyle.Street, numZoomLevels : 16 }); var BingShadedLayer = new
		 * OpenLayers.Layer.VirtualEarth("Bing Shaded", { type :
		 * VEMapStyle.Shaded, numZoomLevels : 16 });
		 */
		var OSMLayer = new OpenLayers.Layer.OSM("OpenStreetMap Map");
		if (SpaceMapSettings.DEFAULT_BASELAYER == "GoogleHybrid") {
			this.spacemap.addLayer(GoogleHybridLayer);
		} else if (SpaceMapSettings.DEFAULT_BASELAYER == "GooglePhysical") {
			this.spacemap.addLayer(GooglePhysicalLayer);
		} else if (SpaceMapSettings.DEFAULT_BASELAYER == "OSM") {
			this.spacemap.addLayer(OSMLayer);
		} else {
			for (i = 0; i < SpaceMapSettings.WMS_BASELAYERS.length; i++) {
				if (SpaceMapSettings.DEFAULT_BASELAYER == SpaceMapSettings.WMS_BASELAYERS[i].title) {
					var newLayer = new OpenLayers.Layer.WMS(
							SpaceMapSettings.WMS_BASELAYERS[i].title,
							SpaceMapSettings.WMS_BASELAYERS[i].url,
							{
								layers : SpaceMapSettings.WMS_BASELAYERS[i].layers
							},
							{
								projection : new OpenLayers.Projection(
										SpaceMapSettings.WMS_BASELAYERS[i].projection),
								displayProjection : new OpenLayers.Projection(
										"EPSG:4326"),
								maxExtent : SpaceMapSettings.WMS_BASELAYERS[i].maxextent,
								numZoomLevels : 19,
								opacity : 0.8
							});
					this.spacemap.addLayer(newLayer);
					this.spacemap.setLayerIndex(newLayer,(101 + i));
				}
			}

		}
		
		/**
		 * if (SpaceMapSettings.BELGIUM_BASELAYER == true) {
		 * this.spacemap.addLayer(BelgiumLayer); } if
		 * (SpaceMapSettings.BINGAERIAL_BASELAYER == true) {
		 * this.spacemap.addLayer(BingAerialLayer); } if
		 * (SpaceMapSettings.BINGSTREET_BASELAYER == true) {
		 * this.spacemap.addLayer(BingStreetLayer); } if
		 * (SpaceMapSettings.BINGSHADED_BASELAYER == true) {
		 * this.spacemap.addLayer(BingShadedLayer); } if
		 * (SpaceMapSettings.BINGHYBRID_BASELAYER == true) {
		 * this.spacemap.addLayer(BingHybridLayer); } if
		 * (SpaceMapSettings.DEMIS_BASELAYER == true) {
		 * this.spacemap.addLayer(DemisLayer); } if
		 * (SpaceMapSettings.GOOGLEHYBRID_BASELAYER == true) {
		 * this.spacemap.addLayer(GoogleHybridLayer); } if
		 * (SpaceMapSettings.GOOGLEPHYSICAL_BASELAYER == true) {
		 * this.spacemap.addLayer(GooglePhysicalLayer); } if
		 * (SpaceMapSettings.METACARTA_BASELAYER == true) {
		 * this.spacemap.addLayer(MetaCartaLayer); } if
		 * (SpaceMapSettings.NASA_BASELAYER == true) {
		 * this.spacemap.addLayer(NasaLayer); } if
		 * (SpaceMapSettings.OSM_BASELAYER == true) {
		 * this.spacemap.addLayer(OSMLayer); } if
		 * (SpaceMapSettings.WAL_BASELAYER == true) {
		 * this.spacemap.addLayer(WalLayer); } if
		 * (SpaceMapSettings.YAHOO_BASELAYER == true) {
		 * this.spacemap.addLayer(YahooLayer); } if
		 * (SpaceMapSettings.CUSTOM1_BASELAYER == true) {
		 * this.spacemap.addLayer(Custom1Layer); } if
		 * (SpaceMapSettings.CUSTOM2_BASELAYER == true) {
		 * this.spacemap.addLayer(Custom2Layer); }
		 */
		for (i = 0; i < SpaceMapSettings.WMS_BASELAYERS.length; i++) {
			if (SpaceMapSettings.DEFAULT_BASELAYER != SpaceMapSettings.WMS_BASELAYERS[i].title) {
				if (SpaceMapSettings.WMS_BASELAYERS[i].title == "GoogleHybrid") {
					this.spacemap.addLayer(GoogleHybridLayer);
				} else if (SpaceMapSettings.WMS_BASELAYERS[i].title == "GooglePhysical") {
					this.spacemap.addLayer(GooglePhysicalLayer);
				} else if (SpaceMapSettings.WMS_BASELAYERS[i].title == "OSM") {
					this.spacemap.addLayer(OSMLayer);
				} else {
					var newLayer = new OpenLayers.Layer.WMS(
							SpaceMapSettings.WMS_BASELAYERS[i].title,
							SpaceMapSettings.WMS_BASELAYERS[i].url,
							{
								layers : SpaceMapSettings.WMS_BASELAYERS[i].layers
							},
							{
								projection : new OpenLayers.Projection(
										SpaceMapSettings.WMS_BASELAYERS[i].projection),
								displayProjection : new OpenLayers.Projection(
										"EPSG:4326"),
								// maxResolution : 0.11,
								maxExtent : SpaceMapSettings.WMS_BASELAYERS[i].maxextent,
								numZoomLevels : 16,
								opacity : 0.8
							});
					this.spacemap.addLayer(newLayer);
					this.spacemap.setLayerIndex(newLayer,(100 +i));
				}
			}
		}
	},
	prepareUserLayers : function() {
		// Creation of a style (color definitions for AOI Layer)
		vDefault = OpenLayers.Util.applyDefaults({
			fillColor : "red",
			strokeColor : "red",
			strokeWidth : "1",
			fillOpacity : 0.3
		}, OpenLayers.Feature.Vector.style["default"]);
		vSelect = OpenLayers.Util.applyDefaults({
			fillColor : "yellow",
			strokeColor : "orange",
			strokeWidth : "2",
			fillOpacity : 0.1
		}, OpenLayers.Feature.Vector.style["default"]);
		vTemp = OpenLayers.Util.applyDefaults({
			fillColor : "red",
			strokeColor : "red",
			strokeWidth : "1",
			fillOpacity : 0.2
		}, OpenLayers.Feature.Vector.style["default"]);
		this.vlayerStyle = new OpenLayers.StyleMap({
			'default' : vDefault,
			'select' : vSelect,
			'temporary' : vTemp
		});
		// Apply style to AOI layer
		this.vlayer = new OpenLayers.Layer.Vector("AOI", {
			displayInLayerSwitcher : false,
			styleMap : this.vlayerStyle
		});

		/**
		 * Add events on the AOI layer
		 * 
		 * featureadded: if an AOI is already present, remove the new feature
		 * added and redraw, else only redraw (bug fix: root cause unknown /
		 * issue: aoi not displayed)) feature added featuremodified: update the
		 * olAOI hidden field (used to send AOI to SSE input form)
		 */

		// mapInit is (optional) client-specific function that replace default
		// events above
		if (typeof mapInit != 'function') {
			//
			this.vlayer.events
					.on({
						'featureadded' : function(evt) {
							// if settings define # AOI, avoid adding additional
							// AOI
							if (evt.feature.geometry instanceof OpenLayers.Geometry.Polygon) {
								if (SpaceMap.aoi_items == SpaceMapSettings.MAX_AOI) {
									SpaceMap.spacemap.getLayersByName('AOI')[0]
											.removeFeatures([ evt.feature ]);
									// bug fix: redraw after remove
									SpaceMap.spacemap.getLayersByName('AOI')[0]
											.redraw();
									SpaceMapUI
											.alert("You can only draw one area of interest. You can delete or modify the created one.");
								} else {
									// clone the new geometry object
									cfeature = evt.feature.geometry.clone();
									// set the AOI hidden field into projection
									// use by the service
									document.getElementById('olAOI').value = cfeature
											.transform(
													SpaceMap.spacemap
															.getProjectionObject(),
													new OpenLayers.Projection(
															SpaceMapSettings.SERVICE_PROJECTION));
									// bug fix: redraw to force AOI display
									SpaceMap.spacemap.getLayersByName('AOI')[0]
											.redraw();
									SpaceMap.aoi_items = SpaceMap.aoi_items + 1;
								}
							} else if (evt.feature.geometry instanceof OpenLayers.Geometry.Point) {
								// if point, case of specific feature to copy a
								// value into an input field
								var copyPopupContent = "Select below the value you want to copy to then click on the target field to paste:<br>";
								copyPopupContent = copyPopupContent
										+ '[<a href="#" onclick="SpaceMapUtils.transferValue(\''
										+ evt.feature.clone().geometry
												.transform(

														map
																.getProjectionObject(),
														new OpenLayers.Projection(
																SpaceMapSettings.SERVICE_PROJECTION)).y
										+ '\');">latitude</a>]';
								copyPopupContent = copyPopupContent
										+ '[<a href="#" onclick="SpaceMapUtils.transferValue(\''
										+ evt.feature.clone().geometry
												.transform(

														map
																.getProjectionObject(),
														new OpenLayers.Projection(
																SpaceMapSettings.SERVICE_PROJECTION)).x
										+ '\');">longitude</a>]';
								// Display in a PopUp - TODO to test
								SpaceMapUI.simplepopup("Copy coordinates",
										evt.feature, copyPopupContent);
							}
						},
						// In case an AOI is modified, update the hidden AOI
						// field (using the right service projection)
						'featuremodified' : function(evt) {
							document.getElementById('olAOI').value = evt.feature.geometry
									.clone()
									.transform(

											this.spacemap.getProjectionObject(),
											new OpenLayers.Projection(
													SpaceMapSettings.SERVICE_PROJECTION));

						}
					});
		}

		// Rlayer is the results layers: style definition
		rDefault = OpenLayers.Util.applyDefaults({
			fillColor : "blue",
			strokeColor : "blue",
			strokeWidth : "1",
			fillOpacity : 0
		}, OpenLayers.Feature.Vector.style["default"]);
		rSelect = OpenLayers.Util.applyDefaults({
			fillColor : "yellow",
			strokeColor : "yellow",
			strokeWidth : "2",
			fillOpacity : 0.3
		}, OpenLayers.Feature.Vector.style["select"]);

		rlayerStyle = new OpenLayers.StyleMap({
			'default' : rDefault,
			'select' : rSelect
		});
		this.rlayer = new OpenLayers.Layer.Vector("Results", {
			displayInLayerSwitcher : false,
			styleMap : rlayerStyle
		});

		this.spacemap.addLayers([ this.vlayer, this.rlayer ]);
	},

	/**
	 * ********************************************************************************************
	 * INTERNAL FUNCTIONS
	 * ********************************************************************************************
	 */

	/**
	 * onSelectAction is called when a result feature is selected It checks if
	 * onSelectActionDefition exists (in the client results output) then call
	 * the function else do nothing.
	 * 
	 * onSelectActionDefinition :
	 * 
	 * If a client (in its input / results html) implements the function
	 * onSelectActionDefinition, this function will be called when a feature
	 * (from the results layer) gets selected (clicked on).
	 * 
	 * The function receives the Openlayers.Feature.Vector instance of the
	 * feature as argument. The function is able to use any Map Viewer function :
	 * i.e. displayFeatureInfo(feature, textToDisplay) : display some text in a
	 * feature popup But also any OpenLayers, ExtJs or GeoExt function.
	 * 
	 * 
	 * @param feature
	 * @return
	 */
	onSelectAction : function(feature) {
		if (typeof onSelectActionDefinition == 'function') {
			onSelectActionDefinition(feature);
		} else {
		}
		if (typeof mapInit != 'function') {
			if (typeof addFeaturesSelectionToBasket == 'function') {
				addFeaturesSelectionToBasket(feature.fid);
			}
		} else {
		}
	},
	/**
	 * onFeatureUnselect is called when a feature (in result area) is unselected
	 * If a feature popup info was displayed it has to be hidden.
	 * 
	 * @param feature
	 * @return
	 */
	onFeatureUnselect : function(feature) {
		// feature.style = OpenLayers.Feature.Vector.style["default"];
		if (feature.popup != null) {
			feature.popup.close();
		}
		feature.popup = null;
		this.onUnselectAction(feature);
	},

	/**
	 * onUnelectAction is called when a result feature is unselected It checks
	 * if onUnselectActionDefition exists (in the client results output) then
	 * call the function else do nothing.
	 * 
	 * @param feature
	 * @return
	 */
	onUnselectAction : function(feature) {
		if (typeof onUnselectActionDefinition == 'function') {
			onUnselectActionDefinition(feature);
		} else {
		}
		if (typeof mapInit == 'function') {
			if (typeof removeFeaturesSelectionFromBasket == 'function') {
				removeFeaturesSelectionFromBasket(feature.fid);
			}
		} else {
		}
	},
	
	addDefaultControls : function() {
		this.spacemap.addControl(new OpenLayers.Control.Navigation({
				documentDrag : true
			}));
			
		var layerSwitcher = new OpenLayers.Control.LayerSwitcher();
        layerSwitcher.ascending = false;
        layerSwitcher.useLegendGraphics = true;
				
		this.spacemap.addControl(layerSwitcher);	
		this.spacemap.addControl(new OpenLayers.Control.PanZoomBar());
		this.spacemap.addControl(new OpenLayers.Control.Scale('spacemapScale'));
		this.spacemap.addControl(new OpenLayers.Control.ScaleLine());
		this.spacemap.addControl(new OpenLayers.Control.MousePosition({ div: document.getElementById('spacemapMousePosition'), numdigits: 5 }));
		//this.spacemap.addControl(new OpenLayers.Control.OverviewMap());
		this.spacemap.addControl(new OpenLayers.Control.PanZoom());
		this.spacemap.addControl(new OpenLayers.Control.ArgParser());
		this.spacemap.addControl(new OpenLayers.Control.Attribution());
	},
	
	getLayerAbstract : function(xmlParser,layerNodes, layer) {		
		for (var i=0; i<layerNodes.length;i++) {				   
			if(xmlParser.getChildValue(xmlParser.getElementsByTagNameNS(layerNodes[i], '*', 'Name')[0]) == layer.params.LAYERS) {    
			  var abstractNodes = xmlParser.getElementsByTagNameNS(layerNodes[i], '*', 'Abstract');
			  if(abstractNodes.length > 0) {                    
				var ab = xmlParser.getChildValue(abstractNodes[0]);
			  }
			}                
		}
		
		if(ab) {
			return ab;
		}
		else {
			return null;
		}
	}	
};